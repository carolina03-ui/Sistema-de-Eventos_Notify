
from fastapi import FastAPI, Request, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.routes import event_routes, user_routes, registration_routes
from database.database import Base, engine, get_db
from app.models.event import Event

# Criação automática das tabelas
Base.metadata.create_all(bind=engine)

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/templates"), name="static")

app.include_router(event_routes.router, prefix="/eventos")
app.include_router(user_routes.router, prefix="/usuarios")
app.include_router(registration_routes.router, prefix="/inscricoes")

templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request, db: Session = Depends(get_db)):
    eventos = db.query(Event).all()
    return templates.TemplateResponse("event_list.html", {"request": request, "eventos": eventos})
