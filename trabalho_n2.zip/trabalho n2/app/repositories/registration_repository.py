from sqlalchemy.orm import Session
from app.models.registration import Registration

def get_registration_by_id(db: Session, registration_id: int):
    return db.query(Registration).filter(Registration.id == registration_id).first()

def get_registrations_by_event(db: Session, event_id: int):
    return db.query(Registration).filter(Registration.event_id == event_id).all()
