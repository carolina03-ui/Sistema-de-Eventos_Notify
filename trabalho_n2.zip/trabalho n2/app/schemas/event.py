from pydantic import BaseModel
from datetime import datetime

class EventBase(BaseModel):
    name: str
    description: str | None = None
    date: datetime

class EventCreate(EventBase):
    pass

class EventResponse(EventBase):
    id: int

    class Config:
        orm_mode = True
