from sqlalchemy.orm import Session
from app.models.user import User
from database.database import get_db

# Função para registrar um usuário
def register_user(db: Session, username: str, email: str, hashed_password: str):
    new_user = User(username=username, email=email, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user
