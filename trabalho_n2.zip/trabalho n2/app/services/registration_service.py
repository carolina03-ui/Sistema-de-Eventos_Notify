from sqlalchemy.orm import Session
from app.models.registration import Registration
from database.database import get_db

# Função para registrar participante
def register_participant(db: Session, name: str, event_id: int):
    new_participant = Registration(name=name, event_id=event_id)
    db.add(new_participant)
    db.commit()
    db.refresh(new_participant)
    return new_participant

# Função para obter participantes de um evento específico
def get_participants_by_event(db: Session, event_id: int):
    return db.query(Registration).filter(Registration.event_id == event_id).all()
