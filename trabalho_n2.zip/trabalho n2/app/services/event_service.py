from sqlalchemy.orm import Session
from app.models.event import Event
from database.database import get_db

# Função para registrar um evento
def create_event(db: Session, name: str, date: str):
    new_event = Event(name=name, date=date)
    db.add(new_event)
    db.commit()
    db.refresh(new_event)
    return new_event

# Função para listar eventos
def list_events(db: Session):
    return db.query(Event).all()
