from sqlalchemy import Column, Integer, String, Date
from database.database import Base  # Importe Base do seu arquivo de configuração

class Event(Base):
    __tablename__ = 'events'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    date = Column(Date, nullable=False)
    description = Column(String, nullable=True)

    def __repr__(self):
        return f"<Event(id={self.id}, name={self.name}, date={self.date}, description={self.description})>"