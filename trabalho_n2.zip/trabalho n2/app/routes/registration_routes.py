
from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from app.models.registration import Registration
from app.models.user import User
from app.models.event import Event

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def formulario_inscricao(request: Request, db: Session = Depends(get_db)):
    usuarios = db.query(User).all()
    eventos = db.query(Event).all()
    return templates.TemplateResponse("registration_form.html", {"request": request, "usuarios": usuarios, "eventos": eventos})

@router.post("/criar")
async def criar_inscricao(usuario_id: int = Form(...), evento_id: int = Form(...), db: Session = Depends(get_db)):
    inscricao = Registration(usuario_id=usuario_id, evento_id=evento_id)
    db.add(inscricao)
    db.commit()
    return RedirectResponse(url="/", status_code=303)
