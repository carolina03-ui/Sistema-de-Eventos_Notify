
from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from app.models.user import User

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def formulario_usuario(request: Request, db: Session = Depends(get_db)):
    usuarios = db.query(User).all()
    return templates.TemplateResponse("user_form.html", {"request": request, "usuarios": usuarios})

@router.post("/criar")
async def criar_usuario(nome: str = Form(...), email: str = Form(...), db: Session = Depends(get_db)):
    novo = User(nome=nome, email=email)
    db.add(novo)
    db.commit()
    return RedirectResponse(url="/", status_code=303)
