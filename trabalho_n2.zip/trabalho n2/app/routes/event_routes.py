
from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database.database import get_db
from app.models.event import Event

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
async def listar_eventos(request: Request, db: Session = Depends(get_db)):
    eventos = db.query(Event).all()
    return templates.TemplateResponse("event_list.html", {"request": request, "eventos": eventos})

@router.get("/cadastrar", response_class=HTMLResponse)
async def formulario_evento(request: Request):
    return templates.TemplateResponse("event_form.html", {"request": request})

@router.post("/criar")
async def criar_evento(nome: str = Form(...), data: str = Form(...), db: Session = Depends(get_db)):
    novo = Event(nome=nome, data=data)
    db.add(novo)
    db.commit()
    return RedirectResponse(url="/", status_code=303)
