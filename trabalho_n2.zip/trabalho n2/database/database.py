from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

DATABASE_URL = f"postgresql://{os.getenv('POSTGRES_USER', 'postgres')}:{os.getenv('POSTGRES_PASSWORD', 'password123')}@{os.getenv('POSTGRES_HOST', '127.0.0.1')}:{os.getenv('DATABASE_PORT', '5432')}/{os.getenv('POSTGRES_DB', 'fastapi')}"


if not DATABASE_URL:
    raise ValueError("DATABASE_URL não está definida no arquivo .env")

# Criar engine de conexão
engine = create_engine(DATABASE_URL)

# Criar sessão de banco de dados
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Criar base declarativa
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
